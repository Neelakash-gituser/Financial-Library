# Financial-Lib
A library built for analyzing financial data, strategies , statistics . 
